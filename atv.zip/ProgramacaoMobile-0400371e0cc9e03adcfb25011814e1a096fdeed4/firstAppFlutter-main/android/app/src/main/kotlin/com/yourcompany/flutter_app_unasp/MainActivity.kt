package com.yourcompany.flutter_app_unasp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
